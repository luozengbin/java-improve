package demo.view.bean;

import java.awt.Color;

import oracle.adf.view.rich.model.CalendarProvider;

public class ProviderDataBean {

    private CalendarProvider _provider;
    private Color _color;

    public ProviderDataBean(CalendarProvider provider, Color color) {
        _provider = provider;
        _color = color;
    }

    public void setColor(Color _color) {
        this._color = _color;
    }

    public Color getColor() {
        return _color;
    }

    public boolean isEnabled() {
        return _provider.getEnabled().equals(CalendarProvider.Enabled.ENABLED);
    }

    public void setEnabled(boolean enabled) {
        if (enabled)
            _provider.setEnabled(CalendarProvider.Enabled.ENABLED);
        else
            _provider.setEnabled(CalendarProvider.Enabled.DISABLED);
    }

}
