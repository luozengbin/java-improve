package demo.view.define;

public interface BaseDefine {
    
    String MEETING_PROVIDER_ID = "uid=meeting,ou=People,dc=syns,dc=net";
  
    String EJB_MODEL_FREFIX = "CalendarDemo/EJBModel/";
}
