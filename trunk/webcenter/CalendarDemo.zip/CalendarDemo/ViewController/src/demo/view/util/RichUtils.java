package demo.view.util;

import java.awt.Color;

import java.util.ArrayList;
import java.util.List;

import oracle.adf.view.rich.util.CalendarActivityRamp;

public class RichUtils {

    public static List<Color> getDefaultColors() {
        List<Color> defaultColors = new ArrayList<Color>(12);
        CalendarActivityRamp redRamp =
            CalendarActivityRamp.getActivityRamp(CalendarActivityRamp.RampKey.RED);
        CalendarActivityRamp orangeRamp =
            CalendarActivityRamp.getActivityRamp(CalendarActivityRamp.RampKey.ORANGE);
        CalendarActivityRamp blueRamp =
            CalendarActivityRamp.getActivityRamp(CalendarActivityRamp.RampKey.BLUE);
        CalendarActivityRamp greenRamp =
            CalendarActivityRamp.getActivityRamp(CalendarActivityRamp.RampKey.GREEN);
        CalendarActivityRamp goldRamp =
            CalendarActivityRamp.getActivityRamp(CalendarActivityRamp.RampKey.GOLD);
        CalendarActivityRamp tealRamp =
            CalendarActivityRamp.getActivityRamp(CalendarActivityRamp.RampKey.TEAL);
        CalendarActivityRamp lavendarRamp =
            CalendarActivityRamp.getActivityRamp(CalendarActivityRamp.RampKey.LAVENDAR);
        CalendarActivityRamp seaweedRamp =
            CalendarActivityRamp.getActivityRamp(CalendarActivityRamp.RampKey.SEAWEED);
        CalendarActivityRamp indigoRamp =
            CalendarActivityRamp.getActivityRamp(CalendarActivityRamp.RampKey.INDIGO);
        CalendarActivityRamp plumRamp =
            CalendarActivityRamp.getActivityRamp(CalendarActivityRamp.RampKey.PLUM);
        CalendarActivityRamp limeRamp =
            CalendarActivityRamp.getActivityRamp(CalendarActivityRamp.RampKey.LIME);
        CalendarActivityRamp midnightblueRamp =
            CalendarActivityRamp.getActivityRamp(CalendarActivityRamp.RampKey.MIDNIGHTBLUE);

        defaultColors.add(redRamp.getRepresentativeColor());
        defaultColors.add(orangeRamp.getRepresentativeColor());
        defaultColors.add(blueRamp.getRepresentativeColor());
        defaultColors.add(greenRamp.getRepresentativeColor());
        defaultColors.add(goldRamp.getRepresentativeColor());
        defaultColors.add(tealRamp.getRepresentativeColor());
        defaultColors.add(lavendarRamp.getRepresentativeColor());
        defaultColors.add(seaweedRamp.getRepresentativeColor());
        defaultColors.add(indigoRamp.getRepresentativeColor());
        defaultColors.add(plumRamp.getRepresentativeColor());
        defaultColors.add(limeRamp.getRepresentativeColor());
        defaultColors.add(midnightblueRamp.getRepresentativeColor());

        return defaultColors;
    }
}
