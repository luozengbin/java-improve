package demo.view.bean;

import demo.view.bean.model.ActivityType;

import java.util.Date;
import java.util.Map;
import java.util.TimeZone;

import oracle.adf.view.rich.model.CalendarActivity;

import demo.view.bean.model.DemoCalendarActivity;

import demo.view.util.DebugUtils;

import javax.faces.model.SelectItem;


/**
 * ������񓝍��r�[��
 */
public class DemoCalendarActivityBean {
    
    //�W���������f��
    private DemoCalendarActivity _activity = null;
    
    //�����^�C�v
    private ActivityType _activityType = null;
    
    //�����^�C�v�I�����X�g
    private SelectItem[] _activityTypes = null;
      
    //�ʒm�t���O
    private boolean _notice = false;
    
    //�I���t���O
    private boolean _allDay = false;
    
    //���l�t���O
    private String _remarks = null;
    
    private TimeZone _tz;

    public DemoCalendarActivityBean(DemoCalendarActivity activity,
                                    TimeZone tz) {
        _tz = tz;
        _activity = activity;

        if (CalendarActivity.TimeType.ALLDAY.equals(_activity.getTimeType())) {
            _allDay = true;
        } else {
            _allDay = false;
        }
        
        _activityType = ActivityType.EVENT;
        
        _activityTypes = new SelectItem[2];
        _activityTypes[0] = new SelectItem(ActivityType.EVENT, ActivityType.EVENT.getDispalyName(), null, false);
        _activityTypes[1] = new SelectItem(ActivityType.MEETING, ActivityType.MEETING.getDispalyName(), null, false);
        
        DebugUtils.traceInConsole(_activityTypes);
    }

    public String getId() {
        return _activity.getId();
    }

    public String getTitle() {
        return _activity.getTitle();
    }


    public void setTitle(String title) {
        _activity.setTitle(title);
    }

    public String getProviderDisplayName() {
        return _activity.getProvider().getDisplayName();
    }


    public String getLocation() {
        return _activity.getLocation();
    }

    public void setLocation(String location) {
        _activity.setLocation(location);
    }

    public Date getFrom() {
        return _activity.getStartDate(_tz);
    }

    public void setFrom(Date from) {
        _activity.setStartDate(from, _tz);
    }

    public Date getTo() {
        return _activity.getEndDate(_tz);
    }

    public void setTo(Date to) {
        _activity.setEndDate(to, _tz);
    }

    public boolean isAllDay() {
        return _allDay;
    }


    public void setAllDay(boolean allDay) {
        _allDay = allDay;
    }

    public boolean isReminder() {
        if (_activity.getReminder() == CalendarActivity.Reminder.ON) {
            return true;
        }
        return false;
    }

    public void setReminder(boolean reminder) {
        _activity.setReminder(reminder ? CalendarActivity.Reminder.ON :
                              CalendarActivity.Reminder.OFF);
    }

    public boolean isRecurring() {
        if (_activity.getRecurring() == CalendarActivity.Recurring.RECURRING) {
            return true;
        }
        return false;
    }
    
    

    public void setRecurring(boolean isRecurring) {
        if (isRecurring) {
            _activity.setRecurring(CalendarActivity.Recurring.RECURRING);
        } else {
            if (_activity.getRecurring() ==
                CalendarActivity.Recurring.RECURRING) {
                _activity.setRecurring(CalendarActivity.Recurring.CHANGED);
            } else {
                _activity.setRecurring(CalendarActivity.Recurring.SINGLE);
            }
        }
    }


    public Map<String, Object> getCustomAttributes() {
        return _activity.getCustomAttributes();
    }


    public DemoCalendarActivity getActivity() {
        return _activity;
    }

    public void setActivity(DemoCalendarActivity activity) {
        _activity = activity;
    }

    public void setNotice(boolean _notice) {
        this._notice = _notice;
    }

    public boolean isNotice() {
        return _notice;
    }

    public void setRemarks(String _remarks) {
        this._remarks = _remarks;
    }

    public String getRemarks() {
        return _remarks;
    }

    public SelectItem[] getActivityTypes() {
        return _activityTypes;
    }

    public void setActivityType(ActivityType _activityType) {
        this._activityType = _activityType;
    }

    public ActivityType getActivityType() {
        return _activityType;
    }
}
