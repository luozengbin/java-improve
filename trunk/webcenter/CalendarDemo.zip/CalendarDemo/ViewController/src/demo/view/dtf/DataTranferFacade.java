package demo.view.dtf;

import demo.model.entity.Provider;
import demo.model.facade.EntityService;

import demo.view.bean.model.DemoCalendarProvider;
import demo.view.util.DebugUtils;
import demo.view.util.EJBUtils;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

import oracle.adf.view.rich.model.CalendarProvider;


public final class DataTranferFacade {

    public static List<CalendarProvider> getCalendarProviderByIds(String ... providerIds) {

        List<CalendarProvider> result = new ArrayList<CalendarProvider>();

        List<Provider> providers = getEntityService().getEntityList(Provider.class, (Serializable[])providerIds);
        DebugUtils.traceInConsole(providers);

        for (Provider provider : providers) {
            result.add(new DemoCalendarProvider(provider.getId(),provider.getDisplayName()));
        }
        return result;
    }
    
    public static CalendarProvider getCalendarProviderById(String providerId) {
        Provider provider = getEntityService().getEntity(Provider.class, providerId);
        return new DemoCalendarProvider(provider.getId(),provider.getDisplayName());
    }

    //TODO �y���\���P�z���[�J���C���^�t�F�[�X�ɕς���

    private static EntityService getEntityService() {
        return EJBUtils.<EntityService>lookup(EntityService.class);
    }

}
