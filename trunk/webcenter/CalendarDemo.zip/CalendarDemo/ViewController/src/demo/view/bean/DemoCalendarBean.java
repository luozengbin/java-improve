package demo.view.bean;

import demo.view.bean.model.ActivityType;
import demo.view.bean.model.DemoCalendarActivity;
import demo.view.bean.model.DemoCalendarEvent;

import demo.view.util.DateUtils;

import java.util.TimeZone;

import demo.view.bean.model.DemoCalendarModelWrapper;

import demo.view.util.DebugUtils;
import demo.view.util.JSFUtils;

import demo.view.util.RichUtils;

import java.awt.Color;

import java.util.Calendar;
import java.util.Date;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import java.util.concurrent.CopyOnWriteArraySet;

import javax.faces.component.UIComponent;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.view.rich.component.rich.data.RichCalendar;
import oracle.adf.view.rich.datatransfer.DataFlavor;
import oracle.adf.view.rich.datatransfer.Transferable;
import oracle.adf.view.rich.dnd.CalendarDropSite;
import oracle.adf.view.rich.dnd.DnDAction;
import oracle.adf.view.rich.event.CalendarActivityDurationChangeEvent;
import oracle.adf.view.rich.event.CalendarActivityEvent;
import oracle.adf.view.rich.event.CalendarDisplayChangeEvent;
import oracle.adf.view.rich.event.CalendarEvent;
import oracle.adf.view.rich.event.DialogEvent;
import oracle.adf.view.rich.event.DropEvent;
import oracle.adf.view.rich.event.PopupFetchEvent;

import oracle.adf.view.rich.event.TriggerType;
import oracle.adf.view.rich.model.CalendarActivity;
import oracle.adf.view.rich.model.CalendarProvider;

import oracle.adf.view.rich.util.CalendarActivityRamp;
import oracle.adf.view.rich.util.InstanceStyles;

import org.apache.myfaces.trinidad.context.RequestContext;


import oracle.jbo.common.UUID;

public class DemoCalendarBean {

    public static final String _CALENDAR_COMPONENT_ID = "cal";

    //�J�����_�[�̃^�C���]��
    private TimeZone _timeZone = null;

    private Date _activityDay = null;

    //�J�����_�[���
    private DemoCalendarModelBean _modelBean = null;

    //�o�^�p�F�������
    private DemoCalendarActivityBean _newActivity = null;

    //�X�V�p or �폜�p�F�������
    private DemoCalendarActivityBean _currActivity = null;

    //�J�����_�[�C�x���g���i�}�E�X�H�L�[�{�[�h�Ȃǂ̏��j
    private DemoCalendarEvent _calendarEventInfo;

    private List _colorData = null;

    //�v���o�C�_�[���
    private Map<CalendarProvider, ProviderDataBean> _providerData = null;

    //���ׂẴv���o�C�_�[�̊����X�^�C���i��ɐF�j���
    private Map<Set<String>, InstanceStyles> _activityStyles;

    public DemoCalendarBean() {
        super();

        System.out.println("init DemoCalendarBean....");

        _timeZone = DateUtils.getDefaultTimeZone();

        _activityDay = Calendar.getInstance(_timeZone).getTime();

        _modelBean =
                new DemoCalendarModelBean(_timeZone, "uid=s_suzuki,ou=People,dc=syns,dc=net",
                                          null, null);

        _colorData = CalendarActivityRamp.getRampColorKeys();

        _providerData =
                new ConcurrentHashMap<CalendarProvider, ProviderDataBean>(3);

        List<Color> defaultOrderProviderColors = RichUtils.getDefaultColors();

        List<CalendarProvider> providerList =
            _modelBean.getCalendarModel().getProviders();
        _activityStyles =
                new HashMap<Set<String>, InstanceStyles>(providerList.size());

        for (int i = 0; i < providerList.size(); i++) {

            CalendarProvider provider = providerList.get(i);

            Color color =
                defaultOrderProviderColors.get(i % defaultOrderProviderColors.size());

            ProviderDataBean data = new ProviderDataBean(provider, color);

            _providerData.put(provider, data);

            InstanceStyles styles =
                CalendarActivityRamp.getActivityRamp(color);
            Set<String> tags = new CopyOnWriteArraySet<String>();
            tags.add(provider.getId());

            _activityStyles.put(tags, styles);

        }
    }

    /*----------------�A�N�Z�b�T------------------*/

    public void setTimeZone(TimeZone _timeZone) {
        this._timeZone = _timeZone;
    }

    public TimeZone getTimeZone() {
        return _timeZone;
    }

    public void setActivityDay(Date _activityDay) {
        this._activityDay = _activityDay;
    }

    public Date getActivityDay() {
        return this._activityDay;
    }

    public DemoCalendarModelWrapper getCalendarModel() {
        return _modelBean.getCalendarModel();
    }


    public void setNewActivity(DemoCalendarActivityBean newActivity) {
        _newActivity = newActivity;
    }


    public DemoCalendarActivityBean getNewActivity() {
        return _newActivity;
    }

    public void setCurrActivity(DemoCalendarActivityBean currActivity) {
        _currActivity = currActivity;
    }


    public DemoCalendarActivityBean getCurrActivity() {
        return _currActivity;
    }

    public Map<CalendarProvider, ProviderDataBean> getProviderData() {
        return _providerData;
    }

    public List getColorData() {
        return _colorData;
    }

    public Map<Set<String>, InstanceStyles> getActivityStyles() {
        return _activityStyles;
    }

    /*------------------�g���A�N�Z�b�T------------------------*/

    /**
     * �����̃^�C���^�C�v�ύX�F���ԑс��I��.
     * @param activity �����I�u�W�F�N�g
     */
    public void changeTimeToAllDayCalendarActivity(CalendarActivity activity) {
        System.out.println("���ԑс��I��");
        DemoCalendarActivity ca = (DemoCalendarActivity)activity;
        ca.setTimeType(CalendarActivity.TimeType.ALLDAY);
        DemoCalendarModelWrapper model = getCalendarModel();
        model.removeTimeCalendarActivity(ca);
        model.addAllDayCalendarActivity(ca);
    }

    /**
     * �����̃^�C���^�C�v�ύX�F�I�������ԑ�.
     * @param activity �����I�u�W�F�N�g
     */
    public void changeAllDayToTimeCalendarActivity(CalendarActivity activity) {
        System.out.println("�I�������ԑ�");
        DemoCalendarActivity ca = (DemoCalendarActivity)activity;
        ca.setTimeType(CalendarActivity.TimeType.TIME);
        DemoCalendarModelWrapper model = getCalendarModel();
        model.removeAllDayCalendarActivity(ca);
        model.addTimeCalendarActivity(ca);
    }

    /*---------------�C�x���g��`-----------------*/

    //The Calendar event is delivered when the user acts on non-activity, non-toolbar space in the calendar.

    public void calendarListener(CalendarEvent calendarEvent) {

        CalendarActivity.TimeType timeType = calendarEvent.getTimeType();
        Date triggerDate = (Date)calendarEvent.getTriggerDate().clone();

        TriggerType tt = calendarEvent.getTriggerType();

        if (TriggerType.MOUSE.equals(tt)) {
            // TODO see todo in createPopupListener for some additional info
            this._createNewActivity(triggerDate, timeType);
            _calendarEventInfo = null;
        } else {
            _calendarEventInfo = new DemoCalendarEvent(triggerDate, timeType);
        }
    }
    //�o�^��ʕ\���O�̏���

    public void createPopupListener(PopupFetchEvent popupFetchEvent) {
        if (_calendarEventInfo != null) {
            // TODO in some rare cases a new activity is created twice, both in createPopupListener
            // and in calendarListener. For example if I
            //   - right click the context menu,  but then don't select anything in the context menu,
            //   - then I click the calendar to create an activity
            //
            // Considered calling createNewActivity in an actionListener
            // on the commandMenuItem instead, but the actionListener isn't getting called because
            // there's a showPopupBehavior on the commandMenuItem. ShowPopupBehavior cancels
            // the event that triggers it, see
            // Bug 7438294 - showpopupbehavior: add option to not cancel event
            _createNewActivity(_calendarEventInfo.getTriggerDate(),
                               _calendarEventInfo.getTimeType());

            _calendarEventInfo = null;
        }
    }

    //�o�^�ۂ̊����^�C�v�ύX����

    public void changeTimeTypeListener(ValueChangeEvent valueChangeEvent) {
        System.out.println("aaaaa");
          
        if (_newActivity != null && !valueChangeEvent.getNewValue().equals(valueChangeEvent.getOldValue())) {
            
          ActivityType newActivityType = (ActivityType)valueChangeEvent.getNewValue();
            
            if (newActivityType == ActivityType.EVENT) {
                _newActivity.getActivity().changeProvider(_modelBean.getCurrentProvider());
            } else if (newActivityType == ActivityType.MEETING) {
                _newActivity.getActivity().changeProvider(_modelBean.getMeetingProvider());
            }
        }
    }


    //�o�^����

    public void createDialogListener(DialogEvent dialogEvent) {

        DialogEvent.Outcome outcome = dialogEvent.getOutcome();

        if (outcome == DialogEvent.Outcome.ok) {

            // ���f���֊i�[
            _addActivityToModel(_newActivity.getActivity());

            // �^�C���^�C�v����
            _checkAllDay(_newActivity);

            refreshCalendar();
        }
    }

    //The calendarActivity event is delivered when the user acts on a calendar activity, for example clicks on an activity.

    public void activityListener(CalendarActivityEvent calendarActivityEvent) {

        CalendarActivity activity =
            calendarActivityEvent.getCalendarActivity();

        if (activity == null) {
            // no activity with that id is found in the model
            System.out.println("No activity with event " +
                               calendarActivityEvent.toString());
            setCurrActivity(null);
            return;
        }

        setCurrActivity(new DemoCalendarActivityBean((DemoCalendarActivity)activity,
                                                     _timeZone));

    }

    //�X�V����

    public void editDialogListener(DialogEvent dialogEvent) {

        DialogEvent.Outcome outcome = dialogEvent.getOutcome();

        if (outcome == DialogEvent.Outcome.ok) {
            // �^�C���^�C�v����
            _checkAllDay(_currActivity);
            refreshCalendar();
        }

    }

    //�폜����

    public void deleteListener(DialogEvent dialogEvent) {
        DialogEvent.Outcome outcome = dialogEvent.getOutcome();
        if (outcome == DialogEvent.Outcome.ok) {
            _removeActivityFromModel(_currActivity.getActivity());
        }
        setCurrActivity(null);

        refreshCalendar();
    }

    //�폜�����F�X�V�r���[�́u�폜�v�{�^���Ή�

    public void deleteListener01(ActionEvent actionEvent) {
        _removeActivityFromModel(_currActivity.getActivity());
        setCurrActivity(null);

        refreshCalendar();
    }


    public void activityDurationChangeListener(CalendarActivityDurationChangeEvent calendarActivityDurationChangeEvent) {
        CalendarActivity activity =
            calendarActivityDurationChangeEvent.getCalendarActivity();

        System.out.println("resizing......");
        if (activity == null) {
            // no activity with that id is found in the model
            System.out.println("No activity with event " +
                               calendarActivityDurationChangeEvent.toString());
            setCurrActivity(null);

            // Since the user has acted on an activity that couldn't be found, ppr the page so
            // that they no longer see the activity
            refreshCalendar();
            return;
        }

        DemoCalendarActivity demoActivity = (DemoCalendarActivity)activity;
        demoActivity.setEndDate(calendarActivityDurationChangeEvent.getNewEndDate(),
                                _timeZone);
        setCurrActivity(new DemoCalendarActivityBean(demoActivity, _timeZone));
    }


    //�c���c���쏈��

    public DnDAction handleDrop(DropEvent dropEvent) {

        Transferable transferable = dropEvent.getTransferable();
        CalendarDropSite dropSite = (CalendarDropSite)dropEvent.getDropSite();
        Date dropSiteDate = dropSite.getDate();

        CalendarActivity activity =
            (CalendarActivity)transferable.getData(DataFlavor.getDataFlavor(CalendarActivity.class));

        // If we have a calendar activitity that we are moving within the same view
        if (activity != null) {
            _handleCalendarActivityDrop(dropEvent, dropSiteDate, activity);
            return dropEvent.getProposedAction();
        }

        return DnDAction.NONE;
    }

    //�����F�̕ύX����

    public void providerColorChange(ValueChangeEvent valueChangeEvent) {
        UIComponent component = valueChangeEvent.getComponent();
        String providerId =
            component.getAttributes().get("providerId").toString();

        Set<String> providerSet = new CopyOnWriteArraySet<String>();
        providerSet.add(providerId);

        Color newColor = (Color)valueChangeEvent.getNewValue();
        InstanceStyles styles = CalendarActivityRamp.getActivityRamp(newColor);

        _activityStyles.put(providerSet, styles);

        refreshCalendar();
    }

    //�Ώۃv���o�C�_�[�̊����̕\���E��\��

    public void providerEnabledChange(ValueChangeEvent valueChangeEvent) {
        refreshCalendar();
    }

    //�\���r���[�ύX

    public void displayChangeListener(CalendarDisplayChangeEvent dce) {
        Date activeDay = dce.getNewActiveDay();
        if (activeDay != null) {
            //fetch new event from db and push into model

        }
    }

    /*---------------�⏕�R�[�h-------------*/
    // create a new activity with the triggerDate and timeType information.
    // if it is allday, then the endDate is midnight.
    // This is called from the popupFetchListener just before the create popup shows.

    private DemoCalendarActivity _createNewActivity(Date triggerDate,
                                                    CalendarActivity.TimeType timeType) {
        // Get latest activity id
        String activityId = (String)UUID.generateUUID();

        // if it is all day, then set the endDay to be midnight.
        Calendar endCal = Calendar.getInstance(_timeZone);
        endCal.setTime(triggerDate);
        boolean isAllDay = CalendarActivity.TimeType.ALLDAY.equals(timeType);
        boolean isUnknown = CalendarActivity.TimeType.UNKNOWN.equals(timeType);

        if (isAllDay || isUnknown) {
            // default is 1 day for allDay or unknown for end date
            endCal.add(Calendar.DAY_OF_YEAR, 1);
        } else {
            // default is 1 hour for timed activities for end date
            endCal.add(Calendar.HOUR_OF_DAY, 1);
        }


        DemoCalendarActivity activity =
            new DemoCalendarActivity(_modelBean.getCurrentProvider(),
                                     activityId,
                                     ((isAllDay || isUnknown) ?
                                      CalendarActivity.TimeType.ALLDAY :
                                      timeType), triggerDate,
                                     endCal.getTime());

        setNewActivity(new DemoCalendarActivityBean(activity, _timeZone));

        return activity;
    }

    //�J�����_�[���f���Ɋ�����ǉ�����

    private void _addActivityToModel(DemoCalendarActivity activity) {
        DemoCalendarModelWrapper model = getCalendarModel();
        if (CalendarActivity.TimeType.ALLDAY.equals(activity.getTimeType())) {
            model.addAllDayCalendarActivity(activity);
        } else {
            model.addTimeCalendarActivity(activity);
        }
    }

    //�J�����_�[���f������Ɋ������폜����

    private void _removeActivityFromModel(DemoCalendarActivity activity) {
        DemoCalendarModelWrapper model = getCalendarModel();

        //���f������폜
        if (CalendarActivity.TimeType.ALLDAY.equals(activity.getTimeType())) {
            model.removeAllDayCalendarActivity(activity);
        } else {
            model.removeTimeCalendarActivity(activity);
        }
    }

    //�����^�C���^�C�v�̒�������

    private void _checkAllDay(DemoCalendarActivityBean activityBean) {
        // if its all day but the current activity is not then change it
        DemoCalendarActivity activity = activityBean.getActivity();
        boolean isActivityAllDay =
            CalendarActivity.TimeType.ALLDAY.equals(activity.getTimeType());

        if (activityBean.isAllDay() && !isActivityAllDay) {
            changeTimeToAllDayCalendarActivity(activity);
        }
        // else if its not all-day but the current activtiy is, then changhe it
        else if (!activityBean.isAllDay() && isActivityAllDay) {
            changeAllDayToTimeCalendarActivity(activity);
        }
    }

    //�J�����_�[�����t���b�V���[����

    private void refreshCalendar() {
        RequestContext adfContext = RequestContext.getCurrentInstance();
        adfContext.addPartialTarget(JSFUtils.findComponentInRoot(_CALENDAR_COMPONENT_ID));
        //TODO �폜
        this.getCalendarModel().toString();
    }

    //D&D���̊������Ԓ���

    private void _handleCalendarActivityDrop(DropEvent dropEvent,
                                             Date dropSiteDate,
                                             CalendarActivity activity) {

        DemoCalendarActivity demoActivity = ((DemoCalendarActivity)activity);

        Date _proposedStartDate = null;

        // If this is a timed event
        Date startDate = demoActivity.getStartDate(_timeZone);
        Calendar startCal = Calendar.getInstance(_timeZone);
        startCal.setTime(startDate);

        Calendar dropCal = Calendar.getInstance(_timeZone);
        dropCal.setTime(dropSiteDate);

        int startDayOfYear = startCal.get(Calendar.DAY_OF_YEAR);
        int startHour = startCal.get(Calendar.HOUR_OF_DAY);
        int startMin = startCal.get(Calendar.MINUTE);

        int dropDayOfYear = dropCal.get(Calendar.DAY_OF_YEAR);
        int dropHour = dropCal.get(Calendar.HOUR_OF_DAY);
        int dropMin = dropCal.get(Calendar.MINUTE);

        // ��(Day)�����킹��
        if (startDayOfYear != dropDayOfYear) {
            startCal.set(Calendar.DAY_OF_YEAR, dropDayOfYear);
            startCal.set(Calendar.YEAR, dropCal.get(Calendar.YEAR));
            startCal.set(Calendar.MONTH, dropCal.get(Calendar.MONTH));
        }

        // move this activity to the new location
        if (demoActivity.isAllDay()) {

            _proposedStartDate = startCal.getTime();

            Calendar endDayCal = Calendar.getInstance(_timeZone);
            endDayCal.setTime(demoActivity.getEndDate(_timeZone));

            Calendar startDayCal = Calendar.getInstance(_timeZone);
            startDayCal.setTime(demoActivity.getStartDate(_timeZone));

            long delta =
                endDayCal.getTime().getTime() - startDayCal.getTime().getTime();
            Date endDate = new Date(_proposedStartDate.getTime() + delta);

            // update to the new start and end day
            demoActivity.setStartDate(_proposedStartDate, _timeZone);
            demoActivity.setEndDate(endDate, _timeZone);

        } else {
            String view =
                ((RichCalendar)dropEvent.getDropComponent()).getView();

            if ((RichCalendar.VIEW_DAY.equals(view) ||
                 RichCalendar.VIEW_WEEK.equals(view)) &&
                CalendarActivity.TimeType.TIME.equals(activity.getTimeType())) {

                if (startHour != dropHour)
                    startCal.set(Calendar.HOUR_OF_DAY, dropHour);

                if (dropMin != startMin) {
                    if (dropMin == 0 && startMin >= 30)
                        startCal.add(Calendar.MINUTE, -30);
                    else if (dropMin == 30 && startMin < 30)
                        startCal.add(Calendar.MINUTE, 30);
                }
            }

            Date endDate = demoActivity.getEndDate(_timeZone);
            long delta = endDate.getTime() - startDate.getTime();

            startDate = startCal.getTime();
            endDate = new Date(startDate.getTime() + delta);

            demoActivity.setStartDate(startDate, _timeZone);
            demoActivity.setEndDate(endDate, _timeZone);
        }

        setCurrActivity(new DemoCalendarActivityBean((DemoCalendarActivity)activity,
                                                     _timeZone));
    }

}
