package demo.view.bean.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;

import oracle.adf.view.rich.model.CalendarActivity;
import oracle.adf.view.rich.model.CalendarModel;
import oracle.adf.view.rich.model.CalendarProvider;

public class DemoCalendarModelWrapper extends CalendarModel {
    
    private List<CalendarProvider> _providers = new ArrayList<CalendarProvider>();
    
    private Map<String, DemoSingleProviderCalendarModel> _models = new ConcurrentHashMap<String, DemoSingleProviderCalendarModel>();
    
    public DemoCalendarModelWrapper() {
    }

    /*----------------- CalendarModel API�̎��� -----------------*/
    @Override
    public CalendarProvider getProvider(String id) {
        for (CalendarProvider provider : _providers) {
            if (id.equals(provider.getId()))
                return provider;
        }
        return null;
    }

    @Override
    public List<CalendarProvider> getProviders() {
        return _providers;
    }

    @Override
    public synchronized List<CalendarActivity> getTimeActivities(Date rangeStart, Date rangeEnd, TimeZone timeZone) {
        List<CalendarActivity> all = new ArrayList<CalendarActivity>();

        for (DemoSingleProviderCalendarModel model : _models.values()) {
            List<CalendarActivity> activities = model.getTimeActivities(rangeStart, rangeEnd, timeZone);
            all.addAll(activities);
        }
        Collections.sort(all, new CalendarActivityComparator());
        return all;
    }
    
    @Override
    public synchronized List<CalendarActivity> getAllDayActivities(Date rangeStart, Date rangeEnd, TimeZone timeZone) {

        List<CalendarActivity> all = new ArrayList<CalendarActivity>();
        for (DemoSingleProviderCalendarModel model : _models.values()) {
            List<CalendarActivity> activities = model.getAllDayActivities(rangeStart, rangeEnd, timeZone);
            all.addAll(activities);
        }
        Collections.sort(all, new CalendarActivityComparator());
        return all;
    }
    
    @Override
    public synchronized CalendarActivity getActivity(String providerId, String activityId, Date rangeStart, Date rangeEnd, TimeZone timeZone) {
        DemoSingleProviderCalendarModel model = _models.get(providerId);
        if (model != null) {
            return model.getActivity(providerId, activityId, rangeStart, rangeEnd, timeZone);
        }
        return null;
    }
    
    /*----------------- �J�X�^�}�C�Y API�̎��� -----------------*/
    /**
     * ���f������I���������폜����
     * @param activity �I������
     */
    public void removeAllDayCalendarActivity(CalendarActivity activity) {
        String providerId = activity.getProvider().getId();
        DemoSingleProviderCalendarModel model = _models.get(providerId);
        if (model != null) {
            model.removeAllDayCalendarActivity(activity);
        }
    }

  /**
   * ���f�����玞�ԑъ������폜����
   * @param activity ���ԑъ���
   */
    public void removeTimeCalendarActivity(CalendarActivity activity) {
        String providerId = activity.getProvider().getId();
        DemoSingleProviderCalendarModel model = _models.get(providerId);
        if (model != null) {
            model.removeTimeCalendarActivity(activity);
        }
    }

  /**
   * ���f���Ɏ��ԑъ�����ǉ�����
   * @param activity ���ԑъ���
   */
    public void addTimeCalendarActivity(DemoCalendarActivity activity) {
        String providerId = activity.getProvider().getId();
        DemoSingleProviderCalendarModel model = _models.get(providerId);

        if (model != null) {
            model.addTimeCalendarActivity(activity);
        }
    }

  /**
   * ���f���ɏI��������ǉ�����
   * @param activity �I������
   */
    public void addAllDayCalendarActivity(DemoCalendarActivity activity) {
        String providerId = activity.getProvider().getId();
        DemoSingleProviderCalendarModel model = _models.get(providerId);
        if (model != null) {
            model.addAllDayCalendarActivity(activity);
        }
    }

    /**
     * �J�����_�[���f���̒ǉ�
     * @param model
     */
    public void addCalendarModel(DemoSingleProviderCalendarModel model) {
        CalendarProvider provider = model.getProvider();
        _providers.add(provider);
        _models.put(provider.getId(), model);
    }

    @Override
    public String toString() {
        
        //TODO �폜
        for (DemoSingleProviderCalendarModel model : _models.values()) {
            model.toString();
        }

        return super.toString();
    }
}
