package demo.view.bean.model;

import java.util.Comparator;
import java.util.Date;
import java.util.TimeZone;

import oracle.adf.view.rich.model.CalendarActivity;

public class CalendarActivityComparator implements Comparator<CalendarActivity> {
    /**
     * If you are sorting just time or just allday activities you can use this constructor, but
     * if you are soring both time and allday activities then use the constructor that takes a
     * timezone since you need to know where to sort all day activities relative to time activities.
     */
    public CalendarActivityComparator() {
        _tz = TimeZone.getDefault();
    }

    /**
     * If you are soring both time and allday activities then use this constructor
     * since you need to know where to sort all day activities relative to time activities.
     */
    public CalendarActivityComparator(TimeZone tz) {
        if (tz == null)
            throw new NullPointerException("timeZone cannot be null");
        _tz = tz;
    }

    private TimeZone _tz;

    public int compare(CalendarActivity activity1,
                       CalendarActivity activity2) {
        Date start1 = activity1.getStartDate(_tz);
        Date start2 = activity2.getStartDate(_tz);

        return start1.compareTo(start2);
    }
}
