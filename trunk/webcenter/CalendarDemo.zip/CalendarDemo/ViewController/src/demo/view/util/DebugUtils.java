package demo.view.util;

import net.arnx.jsonic.JSON;

public final class DebugUtils {
    
    public static void traceInConsole(Object obj){
        System.out.println("debuging---> print object info with json format");
        String text = JSON.encode(obj, true);
        System.out.println(text);
        System.out.println("<---debuging");
    }
    
    public static void traceInConsole(String headerMsg,Object obj){
        System.out.println("debuging--->" + headerMsg);
        String text = JSON.encode(obj, true);
        System.out.println(text);
        System.out.println("<---debuging");
    }
}
