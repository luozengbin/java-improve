package demo.view.bean.model;

public enum ActivityType {
    
    EVENT("�l����"),
    MEETING("��c");
    
    private ActivityType(String displayName){
        this.dispalyName = displayName;
    }
    
    private String dispalyName = null;
    
    public String getDispalyName() {
        return dispalyName;
    }
}
