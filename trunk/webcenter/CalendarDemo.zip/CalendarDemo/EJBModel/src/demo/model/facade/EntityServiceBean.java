package demo.model.facade;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


@Stateless(name = "EntityService",
           mappedName = "CalendarDemo/EJBModel/EntityService")
@Remote
@Local
public class EntityServiceBean implements EntityServiceLocal, EntityService {

    @PersistenceContext(unitName = "EJBModel")
    private EntityManager em;


    public EntityServiceBean() {
        super();
    }

    public <T> void persistEntity(T ... entitys) {
        for (T object : entitys) {
            em.persist(object);
        }
    }

    public <T> T persistEntity(T entity) {
        em.persist(entity);
        return entity;
    }

    public <T> List<T> getEntityList(Class<T> clzss) {
        return em.createQuery("SELECT o FROM " + clzss.getSimpleName() + " o").getResultList();
    }

    public <T> T getEntity(Class<T> clzss, Serializable key) {
        return em.find(clzss, key);
    }
    
    public <T> List<T> getEntityList(Class<T> clzss, Serializable ... keys){
        List<T> result = new ArrayList<T>();
        for (Serializable key : keys) {
          result.add(em.find(clzss, key));
        }
        return result;
    }
}
