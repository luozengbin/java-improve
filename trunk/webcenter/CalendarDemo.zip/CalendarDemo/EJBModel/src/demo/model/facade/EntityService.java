package demo.model.facade;

import java.io.Serializable;

import java.util.List;

import javax.ejb.Remote;

@Remote
public interface EntityService {
    
  public <T> void persistEntity(T ... entitys);
  
  public <T> T persistEntity(T entity);
  
  public <T> List<T> getEntityList(Class<T> clzss);
  
  public <T> T getEntity(Class<T> clzss, Serializable key);
  
  public <T> List<T> getEntityList(Class<T> clzss, Serializable ... keys);
}
