package demo.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "MeetingActivity.findAll", query = "select o from MeetingActivity o")
})
@Table(name = "MEETING_ACTIVITY")
public class MeetingActivity implements Serializable {
    @Column(name="ATTACHEMENT_1")
    private byte[] attachement1;
    @Column(name="ATTACHEMENT_2")
    private byte[] attachement2;
    @Column(name="CONTENT_DATA")
    private char[] contentData;
    @Column(name="PACKED_LUNCH", length = 1000)
    private String packedLunch;
    @Column(length = 1000)
    private String souvenir;
    @OneToOne
    private Activity activity;

    public MeetingActivity() {
    }

    public MeetingActivity(Activity activity, String packedLunch,
                           String souvenir) {
        this.activity = activity;
        this.packedLunch = packedLunch;
        this.souvenir = souvenir;
    }


    public byte[] getAttachement1() {
        return attachement1;
    }

    public void setAttachement1(byte[] attachement1) {
        this.attachement1 = attachement1;
    }

    public byte[] getAttachement2() {
        return attachement2;
    }

    public void setAttachement2(byte[] attachement2) {
        this.attachement2 = attachement2;
    }

    public char[] getContentData() {
        return contentData;
    }

    public void setContentData(char[] contentData) {
        this.contentData = contentData;
    }

    public String getPackedLunch() {
        return packedLunch;
    }

    public void setPackedLunch(String packedLunch) {
        this.packedLunch = packedLunch;
    }

    public String getSouvenir() {
        return souvenir;
    }

    public void setSouvenir(String souvenir) {
        this.souvenir = souvenir;
    }


    public Activity getActivity() {
        return activity;
    }

    public void setActivity(Activity activity) {
        this.activity = activity;
    }
}
