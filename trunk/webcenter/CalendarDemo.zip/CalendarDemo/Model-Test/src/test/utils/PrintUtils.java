package test.utils;

import demo.model.entity.Provider;

public final class PrintUtils {
    
    
  public static void printProvider(Provider provider) {
      System.out.println("displayName = " + provider.getDisplayName());
      System.out.println("email = " + provider.getEmail());
      System.out.println("familyName = " + provider.getFamilyName());
      System.out.println("givenName = " + provider.getGivenName());
      System.out.println("id = " + provider.getId());
  }
  
  public static void printSplitLine(){
    System.out.println("-------------------------------------------------------------");
  }
}
