package test.demo;

import demo.model.entity.Provider;
import demo.model.facade.EntityService;

import test.utils.EJBUtils;
import test.utils.PrintUtils;

public class InitProviderData {
    public static void main(String[] args) {
        try {
            EntityService entityService = EJBUtils.<EntityService>lookup(EntityService.class);

//            Provider provider1 = new Provider();
//            provider1.setId("uid=u_yosita,ou=People,dc=syns,dc=net");
//            provider1.setFamilyName("�g�c");
//            provider1.setGivenName("��Y");
//            provider1.setDisplayName("�g�c����");
//            provider1.setEmail("u_yosita@demo.com");
//
//            Provider provider2 = new Provider();
//            provider2.setId("uid=t_gou,ou=People,dc=syns,dc=net");
//            provider2.setFamilyName("��");
//            provider2.setGivenName("���Y");
//            provider2.setDisplayName("������");
//            provider2.setEmail("t_goua@demo.com");
//
//            entityService.persistEntity(provider1, provider2);
            
            for (Provider provider : entityService.getEntityList(Provider.class)) {
                PrintUtils.printProvider(provider);
                PrintUtils.printSplitLine();
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
