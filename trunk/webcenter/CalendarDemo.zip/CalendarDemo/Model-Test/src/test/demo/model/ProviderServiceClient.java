package test.demo.model;

//import demo.model.Provider;
//import demo.model.ProviderVisible;
//import demo.model.facade.ProviderService;
import java.util.List;

import test.utils.EJBUtils;
import test.utils.PrintUtils;

public class ProviderServiceClient {
    public static void main(String [] args) {
//        try {
//            ProviderService providerService = EJBUtils.lookup(ProviderService.class);
//            for (ProviderVisible providervisible : (List<ProviderVisible>)providerService.getProviderVisibleFindAll()) {
//                 PrintUtils.printProviderVisible(providervisible);
//              PrintUtils.printSplitLine();
//            }
//            for (Provider provider : (List<Provider>)providerService.getProviderFindAll()) {
//                PrintUtils.printProvider(provider);
//              PrintUtils.printSplitLine();
//            }
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
    }
}
