package view.bean;

import org.apache.myfaces.trinidad.event.ReturnEvent;

public class CallBackBean {
    public CallBackBean() {
    }

    public void onCallBack(ReturnEvent returnEvent) {
        // Add event code here...
        System.out.println(returnEvent.getReturnValue());
        
    }
}
