package view.backing;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.RichDialog;
import oracle.adf.view.rich.component.rich.RichDocument;
import oracle.adf.view.rich.component.rich.RichForm;
import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.fragment.RichRegion;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.layout.RichPanelFormLayout;
import oracle.adf.view.rich.component.rich.nav.RichCommandButton;
import oracle.adf.view.rich.context.AdfFacesContext;

import org.apache.myfaces.trinidad.render.ExtendedRenderKitService;

public class Index {
    private RichForm f1;
    private RichDocument d1;
    private RichPanelFormLayout pfl1;
    private RichInputText it1;
    private RichInputText it2;
    private RichCommandButton cb1;
    private RichPopup p1;
    private RichDialog d2;
    private RichRegion r1;


    public void setF1(RichForm f1) {
        this.f1 = f1;
    }

    public RichForm getF1() {
        return f1;
    }

    public void setD1(RichDocument d1) {
        this.d1 = d1;
    }

    public RichDocument getD1() {
        return d1;
    }

    public void setPfl1(RichPanelFormLayout pfl1) {
        this.pfl1 = pfl1;
    }

    public RichPanelFormLayout getPfl1() {
        return pfl1;
    }

    public void setIt1(RichInputText it1) {
        this.it1 = it1;
    }

    public RichInputText getIt1() {
        return it1;
    }

    public void setIt2(RichInputText it2) {
        this.it2 = it2;
    }

    public RichInputText getIt2() {
        return it2;
    }

    public void setCb1(RichCommandButton cb1) {
        this.cb1 = cb1;
    }

    public RichCommandButton getCb1() {
        return cb1;
    }

    public void showPopupActionListener(ActionEvent actionEvent) {
        
        FacesContext context = FacesContext.getCurrentInstance();
        UIComponent source = (UIComponent) actionEvent.getSource();
        String alignId = source.getClientId(context);
        String popupId = p1.getClientId(context);
          
        StringBuilder script = new StringBuilder();
        script.append("var popup = AdfPage.PAGE.findComponent('").append(popupId).append("'); ")
              .append("if (!popup.isPopupVisible()) { ")
              .append("var hints = {}; ")
              .append("hints[AdfRichPopup.HINT_ALIGN_ID] = '").append(alignId).append("'; ") 
              .append("hints[AdfRichPopup.HINT_ALIGN] = AdfRichPopup.ALIGN_AFTER_START; ")
              .append("popup.show(hints);}");
        ExtendedRenderKitService erks =  org.apache.myfaces.trinidad.util.Service.getService(context.getRenderKit(), ExtendedRenderKitService.class);
        erks.addScript(context, script.toString());
        AdfFacesContext.getCurrentInstance().getPageFlowScope().put("inArg", "aaaaa");
      AdfFacesContext.getCurrentInstance().getViewScope().put("inArg", "bbb");
    }
    
  public void hidePopupActionListener(ActionEvent event) 
  {
    FacesContext context = FacesContext.getCurrentInstance();
    String popupId = p1.getClientId(context);
      
    StringBuilder script = new StringBuilder();
    script.append("var popup = AdfPage.PAGE.findComponent('").append(popupId).append("'); ")
          .append("if (popup.isPopupVisible()) { ")
          .append("popup.hide();}");
    ExtendedRenderKitService erks = 
      org.apache.myfaces.trinidad.util.Service.getService(context.getRenderKit(), ExtendedRenderKitService.class);
    erks.addScript(context, script.toString());
  }
    

    public void setP1(RichPopup p1) {
        this.p1 = p1;
    }

    public RichPopup getP1() {
        return p1;
    }

    public void setD2(RichDialog d2) {
        this.d2 = d2;
    }

    public RichDialog getD2() {
        return d2;
    }

    public void setR1(RichRegion r1) {
        this.r1 = r1;
    }

    public RichRegion getR1() {
        return r1;
    }
}
