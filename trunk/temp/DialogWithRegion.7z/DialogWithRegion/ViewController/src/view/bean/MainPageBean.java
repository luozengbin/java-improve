package view.bean;

import oracle.adf.view.rich.context.AdfFacesContext;

public class MainPageBean {
    public MainPageBean() {
        super();
      AdfFacesContext.getCurrentInstance().getPageFlowScope().put("inArg", "aaaaa");
      AdfFacesContext.getCurrentInstance().getViewScope().put("inArg", "bbb");
    }
    
    private String field1;


    public void setField1(String field1) {
        this.field1 = field1;
    }

    public String getField1() {
        return field1;
    }
}
