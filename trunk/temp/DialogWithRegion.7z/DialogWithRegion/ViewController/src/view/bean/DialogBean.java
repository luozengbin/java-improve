package view.bean;

import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.context.AdfFacesContext;

public class DialogBean {
    public DialogBean() {
        super();
    }

    private String input;

    private String output;


    public void setInput(String input) {
        this.input = input;
    }

    public String getInput() {
        System.out.println(AdfFacesContext.getCurrentInstance().getViewScope().get("inArg"));
      
        return (String)AdfFacesContext.getCurrentInstance().getPageFlowScope().get("inArg");
    }

    public void setOutput(String output) {
        this.output = output;
    }

    public String getOutput() {
        return output;
    }

    public void doAction(ActionEvent actionEvent) {
        AdfFacesContext.getCurrentInstance().getPageFlowScope().put("outArg",
                                                                    this.output);

    }
}
