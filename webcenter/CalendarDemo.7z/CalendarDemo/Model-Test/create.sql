create user kpm_demo identified by kpm_demo account unlock;
grant connect to kpm_demo;
grant resource to kpm_demo;

drop sequence kpm_demo.provider_visible_id_seq;
drop sequence kpm_demo.meeting_room_id_seq;
drop table kpm_demo.meeting_booking;
drop table kpm_demo.meeting_activity;
drop table kpm_demo.activity;
drop table kpm_demo.meeting_room;
drop table kpm_demo.provider_visible;
drop table kpm_demo.provider;

--�v���o�C�_�[���
create table kpm_demo.provider(
  id varchar2(100), 
  display_name varchar2(200) not null,
  family_name varchar2(50) not null,
  given_name varchar2(100) not null,
  email varchar2(256)
);
alter table kpm_demo.provider add constraint pk_provider_id primary key(id);

--�v���o�C�_�[,�F�A�\���@or ��\��
create table kpm_demo.provider_visible(
  id number, 
  provider_id varchar2(100) not null,
  accessable_provider_id varchar2(100) not null,
  color varchar(100) not null,
  visible varchar(1) not null
);
alter table kpm_demo.provider_visible add constraint pk_provider_visible_id primary key(id);
alter table kpm_demo.provider_visible add constraint fk_provider_visible_pid FOREIGN KEY(provider_id) REFERENCES kpm_demo.provider(id);
create index kpm_demo.idx_provider_visible_pid on kpm_demo.provider_visible(provider_id);
create sequence kpm_demo.provider_visible_id_seq;

--������{���
create table kpm_demo.activity(
  id varchar2(100),     --UUID���i�[����\��
  title varchar2(500) not null,
  provider_id varchar2(100) not null,
  time_type varchar2(20) not null,
  startDate date not null,
  endDate date not null,
  recurring varchar2(20) not null,
  reminder varchar2(20) not null,
  activity_type varchar2(20) not null,
  notice_flag  varchar2(1) not null,
  location varchar2(500),
  remarks varchar2(2500),
  other_providers varchar2(3000),
  updater varchar2(100) not null,
  update_dt date not null
);
alter table kpm_demo.activity add constraint pk_activity_id primary key(id);
alter table kpm_demo.activity add constraint fk_activity_pid FOREIGN KEY(provider_id) REFERENCES kpm_demo.provider(id);

--��c����
create table kpm_demo.meeting_activity(
  activity_id varchar2(100) not null,
  packed_lunch varchar2(1000),
  souvenir varchar2(1000),
  content_data CLOB,
  attachement_1 BLOB,
  attachement_2 BLOB
);
alter table kpm_demo.meeting_activity add constraint pk_meeting_activity_id primary key (activity_id);
alter table kpm_demo.meeting_activity add constraint fk_meeting_activity_aid FOREIGN KEY(activity_id) REFERENCES kpm_demo.activity(id);
--alter table kpm_demo.meeting_activity add constraint uidx_meeting_activity_aid UNIQUE (activity_id);

--��c��
create table kpm_demo.meeting_room(
  id varchar2(100),
  room_number varchar2(20) not null,
  display_name varchar2(20) not null,
  seat_num number(3) not null,
  white_board_num number(2) not null,
  projector_num number(2) not null,
  monitor_num number(2) not null,
  remarks CLOB,
  photo_data BLOB
);
alter table kpm_demo.meeting_room add constraint pk_meeting_room_id primary key(id);
create sequence kpm_demo.meeting_room_id_seq;

--��c���\����
create table kpm_demo.meeting_booking(
  id varchar2(100),    --UUID
  activity_id varchar2(100),
  meeting_room_id varchar2(100) not null,
  startDate date not null,
  endDate date not null,
  subscriber varchar2(100) not null,
  reserve_time date not null
);
alter table kpm_demo.meeting_booking add constraint pk_meeting_booking_id primary key(id);
alter table kpm_demo.meeting_booking add constraint fk_meeting_booking_aid FOREIGN KEY(activity_id) REFERENCES kpm_demo.activity(id);
alter table kpm_demo.meeting_booking add constraint fk_meeting_booking_mid FOREIGN KEY(meeting_room_id) REFERENCES kpm_demo.meeting_room(id);

--�e�X�g�f�[�^
insert into kpm_demo.provider values('uid=meeting,ou=People,dc=syns,dc=net', '�O���[�v��c', ' ', ' ', 'meeting@demo.com');
insert into kpm_demo.provider values('uid=s_suzuki,ou=People,dc=syns,dc=net', '��؂���', '���', '���Y', 's_suzuki@demo.com');
commit;