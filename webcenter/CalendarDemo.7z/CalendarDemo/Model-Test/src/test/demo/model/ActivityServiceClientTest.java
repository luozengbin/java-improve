package test.demo.model;

import demo.model.entity.Activity;
import demo.model.entity.MeetingActivity;
import demo.model.entity.Provider;
import demo.model.facade.ActivityService;
import demo.model.facade.EntityService;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import org.junit.BeforeClass;
import org.junit.Test;

import test.utils.EJBClientUtils;

public class ActivityServiceClientTest {

    static EntityService entityService = null;
    
  static ActivityService activityService = null;

    static Provider provider = null;

    @BeforeClass
    public static void prepare() {
        entityService =
                EJBClientUtils.<EntityService>lookup(EntityService.class);
        
      activityService = EJBClientUtils.<ActivityService>lookup(ActivityService.class);
        provider =
                entityService.getEntity(Provider.class, "uid=s_suzuki,ou=People,dc=syns,dc=net");
    }


    //@Test
    public void testPersistActivity() {

        Activity activity = new Activity();
        activity.setId(UUID.randomUUID().toString());
        activity.setTitle("test001");
        Calendar cal = Calendar.getInstance();
        activity.setStartdate(new Timestamp(cal.getTime().getTime()));
        cal.add(Calendar.HOUR, 1);
        activity.setEnddate(new Timestamp(cal.getTime().getTime()));
        activity.setProvider(provider);
        activity.setTimeType("TIME");
        activity.setNoticeFlag("1");
        activity.setRecurring("1");
        activity.setReminder("1");
        activity.setActivityType("EVENT");
        activity.setUpdateDt(new Timestamp((new Date()).getTime()));
        activity.setUpdater("akira");

        //entityService.persistEntity(activity);
    }

    //@Test
    public void testPersistMeetingActivity() {

        Activity activity = new Activity();
        activity.setId(UUID.randomUUID().toString());
        activity.setTitle("test002");
        Calendar cal = Calendar.getInstance();
        activity.setStartdate(new Timestamp(cal.getTime().getTime()));
        cal.add(Calendar.HOUR, 1);
        activity.setEnddate(new Timestamp(cal.getTime().getTime()));
        Provider _provider = new Provider();
        _provider.setId("uid=s_suzuki,ou=People,dc=syns,dc=net");
        activity.setProvider(_provider);
        activity.setTimeType("TIME");
        activity.setNoticeFlag("1");
        activity.setRecurring("1");
        activity.setReminder("1");
        activity.setActivityType("MEETING");
        activity.setUpdateDt(new Timestamp((new Date()).getTime()));
        activity.setUpdater("akira");

        MeetingActivity meetingActivity = new MeetingActivity();
        
        meetingActivity.setActivityId(activity.getId());
        
        meetingActivity.setContentData("��c�̏ڍד��e�ł�".toCharArray());
        meetingActivity.setPackedLunch("���g���ٓ��Q��");
        meetingActivity.setSouvenir("�����C�`�S");
        
        activity.setMeetingActivityList(new ArrayList<MeetingActivity>());
        activity.addMeetingActivity(meetingActivity);
        entityService.persistEntity(activity);
    }
    
    @Test
    public void getActivityByProviderId(){
      
      System.out.println(activityService.getActivityFindByProviderId("uid=s_suzuki,ou=People,dc=syns,dc=net").size());
      
      
      
    }
}
