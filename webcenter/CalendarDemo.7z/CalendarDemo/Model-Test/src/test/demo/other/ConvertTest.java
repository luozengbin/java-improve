package test.demo.other;

import oracle.adf.view.rich.model.CalendarActivity;

import org.junit.Test;
import static org.junit.Assert.*;

public class ConvertTest {
    
    @Test
    public void test001(){
      CalendarActivity.TimeType tt = CalendarActivity.TimeType.valueOf("ALLDAY");
      
      assertEquals("", tt, CalendarActivity.TimeType.ALLDAY);
    }
}
