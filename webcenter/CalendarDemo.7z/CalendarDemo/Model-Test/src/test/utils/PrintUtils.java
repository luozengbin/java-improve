package test.utils;

public final class PrintUtils {
    public static void printSplitLine() {
        System.out.println("--------------------------------------");
    }
}
