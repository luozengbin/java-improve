package test.utils;

import com.bea.security.xacml.context.ContextUtils;

import java.io.IOException;

import java.util.Hashtable;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public final class EJBClientUtils {
    
    public static <T> T lookup(Class clzss) {
        try {

            Properties prop = new Properties();
            prop.load(EJBClientUtils.class.getClassLoader().getResourceAsStream("jndi.properties"));
            
            //prop.put(InitialContext.SECURITY_PRINCIPAL, userName);
            //prop.put(InitialContext.SECURITY_CREDENTIALS, password);

            InitialContext ctx = new InitialContext(prop);

            return (T)ctx.lookup(getEJBName(clzss));

        } catch (NamingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    private static String getEJBName(Class clzss) {
        return "CalendarDemo/EJBModel/" + clzss.getSimpleName() + "#" + clzss.getName();
    }
}
