select * from provider;

select * from activity;

select * from meeting_activity;

delete meeting_activity;
delete activity;
commit;