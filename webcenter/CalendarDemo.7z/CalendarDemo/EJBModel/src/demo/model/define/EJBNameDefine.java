package demo.model.define;

public interface EJBNameDefine {
    int MAX_ACTIVITY_MEMBER = 10;
}
