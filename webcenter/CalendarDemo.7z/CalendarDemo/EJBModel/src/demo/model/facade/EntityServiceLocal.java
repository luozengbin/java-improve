package demo.model.facade;

import javax.ejb.Local;

@Local
public interface EntityServiceLocal extends EntityService {
}
