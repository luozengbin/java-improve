package demo.model.facade;

import demo.model.entity.Activity;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless(name = "ActivityService", mappedName = "CalendarDemo/EJBModel/ActivityService")
@Remote
@Local
public class ActivityServiceBean implements ActivityService,
                                            ActivityServiceLocal {
    @PersistenceContext(unitName="EJBModel")
    private EntityManager em;

    public ActivityServiceBean() {
    }

    /** <code>select o from Activity o where o.provider.id = :providerId</code> */
    public List<Activity> getActivityFindByProviderId(String providerId) {
        return em.createNamedQuery("Activity.findByProviderId").setParameter("providerId", providerId).getResultList();
    }
}
