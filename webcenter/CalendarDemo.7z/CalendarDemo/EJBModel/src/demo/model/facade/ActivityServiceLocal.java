package demo.model.facade;

import demo.model.entity.Activity;

import java.util.List;

import javax.ejb.Local;

@Local
public interface ActivityServiceLocal {
    List<Activity> getActivityFindByProviderId(String providerId);
}
