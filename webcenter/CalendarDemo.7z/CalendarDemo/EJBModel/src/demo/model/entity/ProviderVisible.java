package demo.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "ProviderVisible.findAll", query = "select o from ProviderVisible o")
})
@Table(name = "PROVIDER_VISIBLE")
public class ProviderVisible implements Serializable {
    @Column(name="ACCESSABLE_PROVIDER_ID", nullable = false, length = 100)
    private String accessableProviderId;
    @Column(nullable = false, length = 100)
    private String color;
    @Id
    @Column(nullable = false)
    private Long id;
    @Column(nullable = false, length = 1)
    private String visible;
    @ManyToOne
    @JoinColumn(name = "PROVIDER_ID")
    private Provider provider;

    public ProviderVisible() {
    }

    public ProviderVisible(String accessableProviderId, String color, Long id,
                           Provider provider, String visible) {
        this.accessableProviderId = accessableProviderId;
        this.color = color;
        this.id = id;
        this.provider = provider;
        this.visible = visible;
    }

    public String getAccessableProviderId() {
        return accessableProviderId;
    }

    public void setAccessableProviderId(String accessableProviderId) {
        this.accessableProviderId = accessableProviderId;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getVisible() {
        return visible;
    }

    public void setVisible(String visible) {
        this.visible = visible;
    }

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }
}
