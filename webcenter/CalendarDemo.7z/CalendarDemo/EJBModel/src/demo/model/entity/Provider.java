package demo.model.entity;

import java.io.Serializable;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

@Entity
@NamedQueries({
  @NamedQuery(name = "Provider.findAll", query = "select o from Provider o")
})
public class Provider implements Serializable {
    @Column(name="DISPLAY_NAME", nullable = false, length = 200)
    private String displayName;
    @Column(length = 256)
    private String email;
    @Column(name="FAMILY_NAME", nullable = false, length = 50)
    private String familyName;
    @Column(name="GIVEN_NAME", nullable = false, length = 100)
    private String givenName;
    @Id
    @Column(nullable = false, length = 100)
    private String id;
    @OneToMany(mappedBy = "provider")
    private List<Activity> activityList;
    @OneToMany(mappedBy = "provider")
    private List<ProviderVisible> providerVisibleList;

    public Provider() {
    }

    public Provider(String displayName, String email, String familyName,
                    String givenName, String id) {
        this.displayName = displayName;
        this.email = email;
        this.familyName = familyName;
        this.givenName = givenName;
        this.id = id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getGivenName() {
        return givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<Activity> getActivityList() {
        return activityList;
    }

    public void setActivityList(List<Activity> activityList) {
        this.activityList = activityList;
    }

    public Activity addActivity(Activity activity) {
        getActivityList().add(activity);
        activity.setProvider(this);
        return activity;
    }

    public Activity removeActivity(Activity activity) {
        getActivityList().remove(activity);
        activity.setProvider(null);
        return activity;
    }

    public List<ProviderVisible> getProviderVisibleList() {
        return providerVisibleList;
    }

    public void setProviderVisibleList(List<ProviderVisible> providerVisibleList) {
        this.providerVisibleList = providerVisibleList;
    }

    public ProviderVisible addProviderVisible(ProviderVisible providerVisible) {
        getProviderVisibleList().add(providerVisible);
        providerVisible.setProvider(this);
        return providerVisible;
    }

    public ProviderVisible removeProviderVisible(ProviderVisible providerVisible) {
        getProviderVisibleList().remove(providerVisible);
        providerVisible.setProvider(null);
        return providerVisible;
    }
}
