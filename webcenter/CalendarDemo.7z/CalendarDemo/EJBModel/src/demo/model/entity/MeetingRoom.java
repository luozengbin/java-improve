package demo.model.entity;

import java.io.Serializable;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "MeetingRoom.findAll", query = "select o from MeetingRoom o")
})
@Table(name = "MEETING_ROOM")
public class MeetingRoom implements Serializable {
    @Column(name="DISPLAY_NAME", nullable = false, length = 20)
    private String displayName;
    @Id
    @Column(nullable = false, length = 100)
    private String id;
    @Column(name="MONITOR_NUM", nullable = false)
    private Long monitorNum;
    @Column(name="PHOTO_DATA")
    private byte[] photoData;
    @Column(name="PROJECTOR_NUM", nullable = false)
    private Long projectorNum;
    private char[] remarks;
    @Column(name="ROOM_NUMBER", nullable = false, length = 20)
    private String roomNumber;
    @Column(name="SEAT_NUM", nullable = false)
    private Long seatNum;
    @Column(name="WHITE_BOARD_NUM", nullable = false)
    private Long whiteBoardNum;
    @OneToMany(mappedBy = "meetingRoom")
    private List<MeetingBooking> meetingBookingList;

    public MeetingRoom() {
    }

    public MeetingRoom(String displayName, String id, Long monitorNum,
                       Long projectorNum, String roomNumber, Long seatNum,
                       Long whiteBoardNum) {
        this.displayName = displayName;
        this.id = id;
        this.monitorNum = monitorNum;
        this.projectorNum = projectorNum;
        this.roomNumber = roomNumber;
        this.seatNum = seatNum;
        this.whiteBoardNum = whiteBoardNum;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getMonitorNum() {
        return monitorNum;
    }

    public void setMonitorNum(Long monitorNum) {
        this.monitorNum = monitorNum;
    }

    public byte[] getPhotoData() {
        return photoData;
    }

    public void setPhotoData(byte[] photoData) {
        this.photoData = photoData;
    }

    public Long getProjectorNum() {
        return projectorNum;
    }

    public void setProjectorNum(Long projectorNum) {
        this.projectorNum = projectorNum;
    }

    public char[] getRemarks() {
        return remarks;
    }

    public void setRemarks(char[] remarks) {
        this.remarks = remarks;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public Long getSeatNum() {
        return seatNum;
    }

    public void setSeatNum(Long seatNum) {
        this.seatNum = seatNum;
    }

    public Long getWhiteBoardNum() {
        return whiteBoardNum;
    }

    public void setWhiteBoardNum(Long whiteBoardNum) {
        this.whiteBoardNum = whiteBoardNum;
    }

    public List<MeetingBooking> getMeetingBookingList() {
        return meetingBookingList;
    }

    public void setMeetingBookingList(List<MeetingBooking> meetingBookingList) {
        this.meetingBookingList = meetingBookingList;
    }

    public MeetingBooking addMeetingBooking(MeetingBooking meetingBooking) {
        getMeetingBookingList().add(meetingBooking);
        meetingBooking.setMeetingRoom(this);
        return meetingBooking;
    }

    public MeetingBooking removeMeetingBooking(MeetingBooking meetingBooking) {
        getMeetingBookingList().remove(meetingBooking);
        meetingBooking.setMeetingRoom(null);
        return meetingBooking;
    }
}
