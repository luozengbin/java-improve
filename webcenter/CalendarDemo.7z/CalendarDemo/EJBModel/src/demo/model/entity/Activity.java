package demo.model.entity;

import java.io.Serializable;

import java.sql.Timestamp;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

@Entity
@NamedQueries({
  @NamedQuery(name = "Activity.findAll", query = "select o from Activity o"),
  @NamedQuery(name = "Activity.findByProviderId", query = "select o from Activity o where o.provider.id = :providerId")
})
public class Activity implements Serializable {
    @Column(name="ACTIVITY_TYPE", nullable = false, length = 20)
    private String activityType;
    @Column(nullable = false)
    private Timestamp enddate;
    @Id
    @Column(nullable = false, length = 100)
    private String id;
    @Column(length = 500)
    private String location;
    @Column(name="NOTICE_FLAG", nullable = false, length = 1)
    private String noticeFlag;
    @Column(name="OTHER_PROVIDERS", length = 3000)
    private String otherProviders;
    @Column(nullable = false, length = 20)
    private String recurring;
    @Column(length = 2500)
    private String remarks;
    @Column(nullable = false, length = 20)
    private String reminder;
    @Column(nullable = false)
    private Timestamp startdate;
    @Column(name="TIME_TYPE", nullable = false, length = 20)
    private String timeType;
    @Column(nullable = false, length = 500)
    private String title;
    @Column(nullable = false, length = 100)
    private String updater;
    @Column(name="UPDATE_DT", nullable = false)
    private Timestamp updateDt;
    @OneToMany(mappedBy = "activity", cascade = {CascadeType.ALL})
    private List<MeetingBooking> meetingBookingList;
    @ManyToOne
    @JoinColumn(name = "PROVIDER_ID")
    private Provider provider;
    @OneToMany(mappedBy = "activity", cascade = {CascadeType.ALL})
    private List<MeetingActivity> meetingActivityList;

    public Activity() {
    }

    public Activity(String activityType, Timestamp enddate, String id,
                    String location, String noticeFlag, String otherProviders,
                    Provider provider, String recurring, String remarks,
                    String reminder, Timestamp startdate, String timeType,
                    String title, Timestamp updateDt, String updater) {
        this.activityType = activityType;
        this.enddate = enddate;
        this.id = id;
        this.location = location;
        this.noticeFlag = noticeFlag;
        this.otherProviders = otherProviders;
        this.provider = provider;
        this.recurring = recurring;
        this.remarks = remarks;
        this.reminder = reminder;
        this.startdate = startdate;
        this.timeType = timeType;
        this.title = title;
        this.updateDt = updateDt;
        this.updater = updater;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public Timestamp getEnddate() {
        return enddate;
    }

    public void setEnddate(Timestamp enddate) {
        this.enddate = enddate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getNoticeFlag() {
        return noticeFlag;
    }

    public void setNoticeFlag(String noticeFlag) {
        this.noticeFlag = noticeFlag;
    }

    public String getOtherProviders() {
        return otherProviders;
    }

    public void setOtherProviders(String otherProviders) {
        this.otherProviders = otherProviders;
    }


    public String getRecurring() {
        return recurring;
    }

    public void setRecurring(String recurring) {
        this.recurring = recurring;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getReminder() {
        return reminder;
    }

    public void setReminder(String reminder) {
        this.reminder = reminder;
    }

    public Timestamp getStartdate() {
        return startdate;
    }

    public void setStartdate(Timestamp startdate) {
        this.startdate = startdate;
    }

    public String getTimeType() {
        return timeType;
    }

    public void setTimeType(String timeType) {
        this.timeType = timeType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUpdater() {
        return updater;
    }

    public void setUpdater(String updater) {
        this.updater = updater;
    }

    public Timestamp getUpdateDt() {
        return updateDt;
    }

    public void setUpdateDt(Timestamp updateDt) {
        this.updateDt = updateDt;
    }

    public List<MeetingBooking> getMeetingBookingList() {
        return meetingBookingList;
    }

    public void setMeetingBookingList(List<MeetingBooking> meetingBookingList) {
        this.meetingBookingList = meetingBookingList;
    }

    public MeetingBooking addMeetingBooking(MeetingBooking meetingBooking) {
        getMeetingBookingList().add(meetingBooking);
        meetingBooking.setActivity(this);
        return meetingBooking;
    }

    public MeetingBooking removeMeetingBooking(MeetingBooking meetingBooking) {
        getMeetingBookingList().remove(meetingBooking);
        meetingBooking.setActivity(null);
        return meetingBooking;
    }

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    public List<MeetingActivity> getMeetingActivityList() {
        return meetingActivityList;
    }

    public void setMeetingActivityList(List<MeetingActivity> meetingActivityList) {
        this.meetingActivityList = meetingActivityList;
    }

    public MeetingActivity addMeetingActivity(MeetingActivity meetingActivity) {
        getMeetingActivityList().add(meetingActivity);
        meetingActivity.setActivity(this);
        return meetingActivity;
    }

    public MeetingActivity removeMeetingActivity(MeetingActivity meetingActivity) {
        getMeetingActivityList().remove(meetingActivity);
        meetingActivity.setActivity(null);
        return meetingActivity;
    }
}
