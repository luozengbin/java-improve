package demo.model.entity;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "MeetingBooking.findAll", query = "select o from MeetingBooking o")
})
@Table(name = "MEETING_BOOKING")
public class MeetingBooking implements Serializable {
    @Column(nullable = false)
    private Timestamp enddate;
    @Id
    @Column(nullable = false, length = 100)
    private String id;
    @Column(name="RESERVE_TIME", nullable = false)
    private Timestamp reserveTime;
    @Column(nullable = false)
    private Timestamp startdate;
    @Column(nullable = false, length = 100)
    private String subscriber;
    @ManyToOne
    @JoinColumn(name = "ACTIVITY_ID")
    private Activity activity;
    @ManyToOne
    @JoinColumn(name = "MEETING_ROOM_ID")
    private MeetingRoom meetingRoom;

    public MeetingBooking() {
    }

    public MeetingBooking(Activity activity, Timestamp enddate, String id,
                          MeetingRoom meetingRoom, Timestamp reserveTime,
                          Timestamp startdate, String subscriber) {
        this.activity = activity;
        this.enddate = enddate;
        this.id = id;
        this.meetingRoom = meetingRoom;
        this.reserveTime = reserveTime;
        this.startdate = startdate;
        this.subscriber = subscriber;
    }


    public Timestamp getEnddate() {
        return enddate;
    }

    public void setEnddate(Timestamp enddate) {
        this.enddate = enddate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public Timestamp getReserveTime() {
        return reserveTime;
    }

    public void setReserveTime(Timestamp reserveTime) {
        this.reserveTime = reserveTime;
    }

    public Timestamp getStartdate() {
        return startdate;
    }

    public void setStartdate(Timestamp startdate) {
        this.startdate = startdate;
    }

    public String getSubscriber() {
        return subscriber;
    }

    public void setSubscriber(String subscriber) {
        this.subscriber = subscriber;
    }

    public Activity getActivity() {
        return activity;
    }

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    public MeetingRoom getMeetingRoom() {
        return meetingRoom;
    }

    public void setMeetingRoom(MeetingRoom meetingRoom) {
        this.meetingRoom = meetingRoom;
    }
}
