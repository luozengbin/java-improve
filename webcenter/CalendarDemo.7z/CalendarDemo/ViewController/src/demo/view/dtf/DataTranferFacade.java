package demo.view.dtf;

import demo.model.entity.Activity;
import demo.model.entity.Provider;
import demo.model.facade.ActivityService;
import demo.model.facade.EntityService;

import demo.view.bean.DemoCalendarActivityBean;
import demo.view.bean.model.ActivityType;
import demo.view.bean.model.DemoCalendarActivity;
import demo.view.bean.model.DemoCalendarProvider;
import demo.view.util.DateUtils;
import demo.view.util.DebugUtils;
import demo.view.util.EJBUtils;

import java.io.Serializable;


import java.util.ArrayList;
import java.util.List;

import java.util.TimeZone;

import oracle.adf.view.rich.model.CalendarActivity;
import oracle.adf.view.rich.model.CalendarProvider;


public final class DataTranferFacade {

    //TODO �y���\���P�z���[�J���C���^�t�F�[�X�ɕς���

    private static EntityService getEntityService() {
        return EJBUtils.<EntityService>lookup(EntityService.class);
    }

    private static ActivityService geActivityService() {
        return EJBUtils.<ActivityService>lookup(ActivityService.class);
    }

    public static List<CalendarProvider> getCalendarProviderByIds(String... providerIds) {

        List<CalendarProvider> result = new ArrayList<CalendarProvider>();

        List<Provider> providers =
            getEntityService().getEntityList(Provider.class,
                                             (Serializable[])providerIds);
        DebugUtils.traceInConsole(providers);

        for (Provider provider : providers) {
            result.add(new DemoCalendarProvider(provider.getId(),
                                                provider.getDisplayName()));
        }
        return result;
    }

    public static CalendarProvider getCalendarProviderById(String providerId) {
        Provider provider = getEntityService().getEntity(Provider.class, providerId);
        DebugUtils.traceInConsole(provider);
        return new DemoCalendarProvider(provider.getId(), provider.getDisplayName());
    }

    public static void persistActivityBean(DemoCalendarActivityBean activityBean,
                                           String operatorId) {

        Activity activity = new Activity();
        activity.setId(activityBean.getId());
        activity.setTitle(activityBean.getTitle());
        activity.setStartdate(DateUtils.convertToTimestamp(activityBean.getFrom()));
        activity.setEnddate(DateUtils.convertToTimestamp(activityBean.getTo()));

        activity.setTimeType(activityBean.getActivity().getTimeType().toString());
        activity.setNoticeFlag(activityBean.getActivity().getRecurring().toString());
        activity.setRecurring(activityBean.getActivity().getRecurring().toString());
        activity.setReminder(activityBean.getActivity().getReminder().toString());
        activity.setActivityType(activityBean.getActivityType().toString());

        activity.setLocation(activityBean.getLocation());
        activity.setNoticeFlag(activityBean.isNotice() ? "1" : "0");
        activity.setRemarks(activityBean.getRemarks());

        Provider provider = new Provider();
        provider.setId(activityBean.getActivity().getProvider().getId());
        activity.setProvider(provider);

        activity.setUpdateDt(DateUtils.getTimestamp());
        activity.setUpdater(operatorId);

        getEntityService().mergerEntity(activity);
    }

    public static void removeActivity(String activityId) {
        getEntityService().removeEntity(Activity.class, activityId);
    }
    
    public static List<CalendarActivity> getDemoCalendarActivityList(CalendarProvider provider) {
        List<CalendarActivity> result = new ArrayList<CalendarActivity>();
        CalendarActivity calendarActivity = null;
        
        for (Activity activity : geActivityService().getActivityFindByProviderId(provider.getId())) {
            calendarActivity = new DemoCalendarActivity(provider, activity.getId());
            tranferData(calendarActivity, activity);
            result.add(calendarActivity);
        }
        return result;
    }
    
    public static void loadDemoCalendarActivityBeanInfo(DemoCalendarActivityBean demoCalendarActivityBean) {
        
        Activity activity = getEntityService().getEntity(Activity.class, demoCalendarActivityBean.getId());
        //��{���̍ēǍ�
        tranferData(demoCalendarActivityBean.getActivity(), activity);
        
        demoCalendarActivityBean.setActivityType(ActivityType.valueOf(activity.getActivityType()));
        
        demoCalendarActivityBean.setNotice(activity.getNoticeFlag().equals("1") ? true : false);
        
        //�g�����̍ēǂݍ���
        if(demoCalendarActivityBean.getActivityType() == ActivityType.EVENT && activity.getRemarks() != null && activity.getRemarks().length() > 0){
            demoCalendarActivityBean.setRemarks(String.valueOf(activity.getRemarks()));
        } else if(demoCalendarActivityBean.getActivityType() == ActivityType.MEETING){
            
        }
        
        DebugUtils.traceInConsole(demoCalendarActivityBean, 1);
    }
  
    private static void tranferData(CalendarActivity calendarActivity, Activity activity) {
        calendarActivity.setTimeType(CalendarActivity.TimeType.valueOf(activity.getTimeType()));
        calendarActivity.setStartDate(activity.getStartdate(), DateUtils.getDefaultTimeZone());
        calendarActivity.setEndDate(activity.getEnddate(), DateUtils.getDefaultTimeZone());
        calendarActivity.setTitle(activity.getTitle());
        calendarActivity.setLocation(activity.getLocation());
        calendarActivity.setRecurring(CalendarActivity.Recurring.valueOf(activity.getRecurring()));
        calendarActivity.setReminder(CalendarActivity.Reminder.valueOf(activity.getReminder()));
    }
}
