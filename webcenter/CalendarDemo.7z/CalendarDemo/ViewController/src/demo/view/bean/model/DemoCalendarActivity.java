package demo.view.bean.model;

import java.util.Date;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.CopyOnWriteArraySet;

import oracle.adf.view.rich.model.CalendarActivity;
import oracle.adf.view.rich.model.CalendarProvider;


public class DemoCalendarActivity extends CalendarActivity {

    private Date _startDate;
    private Date _endDate;
    private TimeType _timeType;
    private String _id;
    private CalendarProvider _provider;
    private String _location;
    private String _title;
    private Set<String> _tags;
    private CalendarActivity.Recurring _recurring = Recurring.SINGLE;
    private CalendarActivity.Reminder _reminder = Reminder.OFF;

    public DemoCalendarActivity(CalendarProvider provider, String id) {
        _init(provider, id);
    }

    public DemoCalendarActivity(CalendarProvider provider, String id,
                                TimeType timeType, Date startDate,
                                Date endDate) {
        _startDate = startDate;
        _endDate = endDate;
        _timeType = timeType;
        _init(provider, id);
    }


    public void changeProvider(CalendarProvider provider) {
        _provider = provider;
        _tags = new CopyOnWriteArraySet<String>();
        _tags.add(provider.getId());
    }

    private void _init(CalendarProvider provider, String id) {
        _id = id;
        _provider = provider;
        _tags = new CopyOnWriteArraySet<String>();
        _tags.add(provider.getId());
    }

    @Override
    public void setTags(Set<String> tags) {
        _tags = tags;
    }


    @Override
    public boolean isReadOnly() {
        return false;
    }

    @Override
    public Set<String> getTags() {
        return _tags;
    }

    @Override
    public String getId() {
        return _id;
    }

    @Override
    public Date getEndDate(TimeZone tz) {
        return (Date)_endDate.clone();
    }

    @Override
    public Date getStartDate(TimeZone tz) {
        return (Date)_startDate.clone();
    }

    @Override
    public void setStartDate(Date startDate, TimeZone tz) {
        _startDate = new Date(startDate.getTime());
    }

    @Override
    public void setEndDate(Date endDate, TimeZone tz) {
        _endDate = new Date(endDate.getTime());
    }


    @Override
    public void setTitle(String title) {
        _title = title;
    }

    @Override
    public String getTitle() {
        return _title;
    }

    @Override
    public void setTimeType(TimeType timeType) {
        _timeType = timeType;
        
        
        
    }

    @Override
    public TimeType getTimeType() {
        return _timeType;
    }

    @Override
    public CalendarProvider getProvider() {
        return _provider;
    }

    @Override
    public void setLocation(String location) {
        _location = location;
    }

    @Override
    public String getLocation() {
        return _location;
    }


    @Override
    public void setRecurring(Recurring recurring) {
        _recurring = recurring;
    }

    @Override
    public Recurring getRecurring() {
        return _recurring;
    }

    @Override
    public void setReminder(CalendarActivity.Reminder reminder) {
        _reminder = reminder;
    }

    @Override
    public CalendarActivity.Reminder getReminder() {
        return _reminder;
    }

    public boolean isAllDay() {
        return TimeType.ALLDAY.equals(getTimeType());
    }
}
