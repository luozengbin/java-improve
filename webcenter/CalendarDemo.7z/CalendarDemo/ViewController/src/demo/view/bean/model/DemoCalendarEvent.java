package demo.view.bean.model;


import java.util.Date;

import oracle.adf.view.rich.model.CalendarActivity;

// class to hold the state of the CalendarEvent that we retrieve in our calendarListener
// method. This will later be used in the actionListener for the create context menu.
public class DemoCalendarEvent {
    public DemoCalendarEvent(Date triggerDate,
                             CalendarActivity.TimeType timeType) {
        _triggerDate = triggerDate;
        _timeType = timeType;
    }

    // we save the 'state' of a CalendarEvent if the triggerType is CONTEXT_MENU
    private Date _triggerDate;
    private CalendarActivity.TimeType _timeType;

    public Date getTriggerDate() {
        return _triggerDate;
    }

    public CalendarActivity.TimeType getTimeType() {
        return _timeType;
    }
}
