package demo.view.bean;

import oracle.adf.view.rich.model.CalendarProvider;

import demo.view.bean.model.DemoCalendarModelWrapper;
import demo.view.bean.model.DemoSingleProviderCalendarModel;

import demo.view.define.BaseDefine;
import demo.view.dtf.DataTranferFacade;

import java.util.Date;
import java.util.TimeZone;

public class DemoCalendarModelBean {
    
    private TimeZone _timeZone = null;
    
    private String _providerId = null;

    private Date _startRange = null;

    private Date _endRange = null;

    private CalendarProvider _currentProvider = null;
    
    private CalendarProvider _meetingProvider = null;

    private DemoCalendarModelWrapper _modelWrapper = null;

    public DemoCalendarModelBean(TimeZone _timeZone, String _providerId,
                                 Date _startRange, Date _endRange) {
        super();
        this._timeZone = _timeZone;
        this._providerId = _providerId;
        this._startRange = _startRange;
        this._endRange = _endRange;
        
        _modelWrapper = new DemoCalendarModelWrapper();
        
        _currentProvider = DataTranferFacade.getCalendarProviderById(_providerId);
        DemoSingleProviderCalendarModel _currentProviderCalendar =  new DemoSingleProviderCalendarModel(_currentProvider);
        _currentProviderCalendar.addCalendarActivity(DataTranferFacade.getDemoCalendarActivityList(_currentProvider));
        _modelWrapper.addCalendarModel(_currentProviderCalendar);
        
        
        _meetingProvider = DataTranferFacade.getCalendarProviderById(BaseDefine.MEETING_PROVIDER_ID);
        DemoSingleProviderCalendarModel _meetingProviderCalendar =  new DemoSingleProviderCalendarModel(_meetingProvider);
        _meetingProviderCalendar.addCalendarActivity(DataTranferFacade.getDemoCalendarActivityList(_meetingProvider));
        _modelWrapper.addCalendarModel(_meetingProviderCalendar);
    }

    /*==============================�A�N�Z�b�T==================================*/


    // Public APIs

    public DemoCalendarModelWrapper getCalendarModel() {
        return _modelWrapper;
    }

    public void setProviderId(String _providerId) {
        this._providerId = _providerId;
    }

    public void setStartRange(Date _startRange) {
        this._startRange = _startRange;
    }

    public void setEndRange(Date _endRange) {
        this._endRange = _endRange;
    }

    public CalendarProvider getCurrentProvider() {
        return _currentProvider;
    }

    public void setTimeZone(TimeZone _timeZone) {
        this._timeZone = _timeZone;
    }

    public CalendarProvider getMeetingProvider() {
        return _meetingProvider;
    }
}

