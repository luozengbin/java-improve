package demo.view.bean.model;

import demo.view.util.DebugUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import oracle.adf.view.rich.model.CalendarActivity;
import oracle.adf.view.rich.model.CalendarModel;
import oracle.adf.view.rich.model.CalendarProvider;

public class DemoSingleProviderCalendarModel extends CalendarModel {

    private CalendarProvider _provider;
    private List<CalendarProvider> _providerList;
    private List<CalendarActivity> _allDayActivities = null;
    private List<CalendarActivity> _timeActivities = null;
    private Map<String, CalendarActivity> _activitiesMap = null;

    public DemoSingleProviderCalendarModel(CalendarProvider provider) {
        _provider = provider;
        _providerList = Collections.singletonList(_provider);
        _allDayActivities = new ArrayList<CalendarActivity>();
        _timeActivities = new ArrayList<CalendarActivity>();
        _activitiesMap = new HashMap<String, CalendarActivity>();
    }

    /*----------------- CalendarModel API�̎��� -----------------*/

    @Override
    public CalendarProvider getProvider(String id) {
        if (_provider.getId().equals(id))
            return _provider;
        return null;
    }

    @Override
    public List<CalendarProvider> getProviders() {
        return _providerList;
    }

    @Override
    public synchronized List<CalendarActivity> getTimeActivities(Date rangeStart,
                                                                 Date rangeEnd,
                                                                 TimeZone timeZone) {
        if (_provider.getEnabled().equals(CalendarProvider.Enabled.ENABLED)) {
            return _getActivities(_timeActivities, rangeStart, rangeEnd,
                                  timeZone);
        }
        return Collections.emptyList();
    }

    @Override
    public synchronized List<CalendarActivity> getAllDayActivities(Date rangeStart,
                                                                   Date rangeEnd,
                                                                   TimeZone timeZone) {
        if (_provider.getEnabled().equals(CalendarProvider.Enabled.ENABLED)) {
            return _getActivities(_allDayActivities, rangeStart, rangeEnd,
                                  timeZone);
        }
        return Collections.emptyList();
    }

    @Override
    public synchronized CalendarActivity getActivity(String providerId,
                                                     String activityId,
                                                     Date rangeStart,
                                                     Date rangeEnd,
                                                     TimeZone timezone) {
        return _activitiesMap.get(activityId);
    }

    /*----------------- �J�X�^�}�C�Y API�̎��� -----------------*/

    /**
     * ���f���̎�����擾����
     * @param CalendarProvider ���f���̎���
     */
    public CalendarProvider getProvider() {
        return _provider;
    }

    /**
     * ���f������I���������폜����
     * @param activity �I������
     */
    public void removeAllDayCalendarActivity(CalendarActivity activity) {
        this._activitiesMap.remove(activity.getId());
        this._allDayActivities.remove(activity);
    }

    /**
     * ���f�����玞�ԑъ������폜����
     * @param activity ���ԑъ���
     */
    public void removeTimeCalendarActivity(CalendarActivity activity) {
        this._activitiesMap.remove(activity.getId());
        this._timeActivities.remove(activity);
    }

    /**
     * ���f���Ɋ�����ǉ�����
     * @param activity �I������
     */
    public void addCalendarActivity(List<CalendarActivity> activityList) {
        for (CalendarActivity activity : activityList) {
            if (activity.getTimeType() == CalendarActivity.TimeType.ALLDAY) {
                addAllDayCalendarActivity(activity);
            } else if (activity.getTimeType() ==
                       CalendarActivity.TimeType.TIME) {
                addTimeCalendarActivity(activity);
            }
        }
    }

    /**
     * ���f���Ɋ�����ǉ�����
     * @param activity �I������
     */
    public void addCalendarActivity(CalendarActivity activity) {
        if (activity.getTimeType() == CalendarActivity.TimeType.ALLDAY) {
            addAllDayCalendarActivity(activity);
        } else if (activity.getTimeType() == CalendarActivity.TimeType.TIME) {
            addTimeCalendarActivity(activity);
        }
    }

    /**
     * ���f���Ɏ��ԑъ�����ǉ�����
     * @param activity ���ԑъ���
     */
    public void addTimeCalendarActivity(CalendarActivity activity) {
        this._timeActivities.add(activity);
        Collections.sort(this._timeActivities,
                         new CalendarActivityComparator());
        _activitiesMap.put(activity.getId(), activity);
    }

    /**
     * ���f���ɏI��������ǉ�����
     * @param activity �I������
     */
    public void addAllDayCalendarActivity(CalendarActivity activity) {
        this._allDayActivities.add(activity);
        Collections.sort(this._allDayActivities,
                         new CalendarActivityComparator());
        _activitiesMap.put(activity.getId(), activity);
    }

    /**
     * �w�肳�ꂽ���Ԕ͈͂��犈�����擾����
     * @param allActivities �擾���ƂȂ銈�����X�g
     * @param rangeStart �J�n����
     * @param rangeEnd �I������
     * @param tz �^�C���]��
     * @return �������X�g
     */
    private synchronized List<CalendarActivity> _getActivities(List<CalendarActivity> allActivities,
                                                               Date rangeStart,
                                                               Date rangeEnd,
                                                               TimeZone tz) {

        if (rangeStart == null && rangeEnd == null) {
            return allActivities;
        }
        List<CalendarActivity> activities = new ArrayList<CalendarActivity>();
        Iterator<CalendarActivity> iterator = allActivities.iterator();

        while (iterator.hasNext()) {
            CalendarActivity ca = iterator.next();
            if (CalendarModel.isActivityInRange(ca, tz, rangeStart,
                                                rangeEnd)) {
                activities.add(ca);
            }
        }

        return activities;
    }

    @Override
    public String toString() {

        //TODO �폜
        DebugUtils.traceInConsole("_allDayActivitiesFromThisModel",
                                  _allDayActivities);
        DebugUtils.traceInConsole("_timeActivitiesFromThisModel",
                                  _timeActivities);

        return super.toString();
    }


}
