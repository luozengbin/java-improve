package demo.view.util;

import demo.view.define.BaseDefine;

import javax.naming.InitialContext;

public final class EJBUtils {
    
  public static <T> T lookup(Class clzss) {
      try {
          InitialContext ctx = new InitialContext();
          return (T)ctx.lookup(getEJBName(clzss));
      } catch (Exception e) {
          new RuntimeException(e);
      }
      return null;
  }
  
  private static String getEJBName(Class clzss) {
      return BaseDefine.EJB_MODEL_FREFIX + clzss.getSimpleName() + "#" + clzss.getName();
  }
}
