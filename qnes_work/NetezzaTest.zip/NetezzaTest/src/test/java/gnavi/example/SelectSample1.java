package gnavi.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class SelectSample1 {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("persistenceUnit");
		EntityManager em = emf.createEntityManager();

		String sql = "select * from users where mailaddress=?";

		User user = (User) em.createNativeQuery(sql, User.class)
				.setParameter(1, "test1@example.com").getSingleResult();
		System.out.println(user);

		em.close();
	}
}
