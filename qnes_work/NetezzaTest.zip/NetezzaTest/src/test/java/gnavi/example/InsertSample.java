package gnavi.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class InsertSample {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("persistenceUnit");
		EntityManager em = emf.createEntityManager();

		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			User user = new User();
			user.setMailaddress("test1@example.com");
			user.setPassword("test");

			em.persist(user);

			tx.commit();
		} finally {
			em.close();
		}
	}
}
